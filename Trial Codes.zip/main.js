let queue = ["Elaine", "Althea", "Angelo", "Lito", "Engelbert"];

while (true) {
  let choice = prompt("1. Add customer\n2. Display queue\n3. Exit");

  if (choice == 1) {
    let name = prompt("Enter customer name:");
    queue.push(name);
    alert("Customer " + name + " added with number " + queue.length);
  } 
  else if (choice == 2) {
    console.log(queue);
  } 
  else if (choice == 3) {
    break;
  } 
  else {
    alert("Invalid choice.");
  }

  // Ask customer service representative for a number to service
  let number = prompt("Enter customer number to service:");
  if (number > 0 && number <= queue.length) {
    let customer = queue[number - 1];
    alert("Now servicing customer " + customer);
    queue.splice(number - 1, 1);
    console.log("Updated Queue: ", queue);
  } else {
    alert("Invalid customer number.");
  }
}